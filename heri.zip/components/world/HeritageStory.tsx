"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  motion,
  useMotionValue,
  useMotionValueEvent,
  useScroll,
  useTransform,
  type MotionValue,
} from "framer-motion";
import {
  SCENE_CENTERS,
  SkyLayer,
  WORLD_H,
  WORLD_W,
  WorldDefs,
  WorldLayer,
} from "./art";

const clamp = (n: number, a = 0, b = 1) => Math.min(b, Math.max(a, n));

/** A text panel that fades in/out as the world scrolls past its scene. */
function Panel({
  progress,
  at,
  unitsPerP,
  className = "",
  holdAfter = false,
  holdBefore = false,
  children,
}: {
  progress: MotionValue<number>;
  /** scroll progress (0‥1) at which this scene is centred */
  at: number;
  /** world units travelled per 1.0 of progress */
  unitsPerP: number;
  className?: string;
  holdAfter?: boolean;
  holdBefore?: boolean;
  children: React.ReactNode;
}) {
  const opacity = useMotionValue(0);
  const y = useMotionValue(24);
  const pointer = useTransform(opacity, (o) => (o > 0.45 ? "auto" : "none"));

  const update = useCallback(
    (v: number) => {
      const signed = (v - at) * unitsPerP;
      let d = Math.abs(signed);
      if (holdAfter && signed > 0) d = 0;
      if (holdBefore && signed < 0) d = 0;
      const t = clamp(1 - (d - 170) / 260);
      opacity.set(t);
      y.set((1 - t) * (signed < 0 ? 46 : -46));
    },
    [at, unitsPerP, holdAfter, holdBefore, opacity, y]
  );

  useMotionValueEvent(progress, "change", update);
  useEffect(() => update(progress.get()), [update, progress]);

  return (
    <motion.div
      style={{ opacity, y, pointerEvents: pointer }}
      className={`absolute ${className}`}
    >
      {children}
    </motion.div>
  );
}

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="mb-4 font-mono text-[11px] font-bold uppercase tracking-[0.32em]"
      style={{ color: "var(--accent-text)" }}
    >
      {children}
    </div>
  );
}

const textCard =
  "w-[min(440px,calc(100vw-40px))] text-[#f6f1ff] max-md:rounded-2xl max-md:border max-md:border-white/10 max-md:bg-[#0d0a22]/70 max-md:p-6 max-md:backdrop-blur-xl";

export function HeritageStory() {
  const sectionRef = useRef<HTMLElement>(null);
  const [size, setSize] = useState({ vw: 1440, vh: 900 });

  useEffect(() => {
    const measure = () =>
      setSize({ vw: window.innerWidth, vh: window.innerHeight });
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const geo = useMemo(() => {
    const { vw, vh } = size;
    const s = Math.max(vw / WORLD_W, vh / 1250);
    const worldPxW = WORLD_W * s;
    const worldPxH = WORLD_H * s;
    const travel = Math.max(1, worldPxH - vh);
    const viewUnits = vh / s;
    const unitsPerP = WORLD_H - viewUnits;
    const at = SCENE_CENTERS.map((c) =>
      clamp((c - viewUnits / 2) / unitsPerP)
    );
    return {
      s,
      worldPxW,
      worldPxH,
      offsetX: (vw - worldPxW) / 2,
      travel,
      sectionH: vh + travel,
      unitsPerP,
      at,
    };
  }, [size]);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });

  const worldY = useMotionValue(0);
  const skyY = useMotionValue(0);
  const apply = useCallback(
    (v: number) => {
      worldY.set(-v * geo.travel);
      skyY.set(-v * geo.travel * 0.6);
    },
    [geo.travel, worldY, skyY]
  );
  useMotionValueEvent(scrollYProgress, "change", apply);
  useEffect(() => apply(scrollYProgress.get()), [apply, scrollYProgress]);

  const barScale = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <section
      id="story"
      ref={sectionRef}
      style={{ height: geo.sectionH }}
      className="relative bg-[#0d0820]"
    >
      <div className="sticky top-0 h-dvh w-full overflow-hidden">
        {/* ---- the world: two parallax layers sharing one coordinate space */}
        <motion.svg
          aria-hidden
          viewBox={`0 0 ${WORLD_W} ${WORLD_H}`}
          width={geo.worldPxW}
          height={geo.worldPxH}
          style={{
            position: "absolute",
            top: 0,
            left: geo.offsetX,
            y: skyY,
            overflow: "visible",
          }}
          className="pointer-events-none"
        >
          <WorldDefs />
          <SkyLayer />
        </motion.svg>
        <motion.svg
          aria-hidden
          viewBox={`0 0 ${WORLD_W} ${WORLD_H}`}
          width={geo.worldPxW}
          height={geo.worldPxH}
          style={{
            position: "absolute",
            top: 0,
            left: geo.offsetX,
            y: worldY,
          }}
          className="pointer-events-none"
        >
          <WorldLayer />
        </motion.svg>

        {/* legibility scrim at the very top so the nav always reads */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#0d0a22]/55 to-transparent" />

        {/* ---- copy */}
        <div className="absolute inset-0">
          {/* 0 · hero */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[0]}
            unitsPerP={geo.unitsPerP}
            holdBefore
            className="inset-x-0 top-[13dvh] flex flex-col items-center px-5 text-center text-white"
          >
            <h1 className="wordmark m-0 text-[clamp(34px,8.2vw,112px)] leading-none drop-shadow-[0_6px_30px_rgba(60,20,90,0.45)]">
              Heritage
            </h1>
            <p className="wordmark mt-5 text-[clamp(10px,1.25vw,16px)] font-medium tracking-[0.5em] text-white/70">
              Buildings, remembered
            </p>
          </Panel>

          {/* scroll hint, parked at the bottom so it never sits on the art */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[0]}
            unitsPerP={geo.unitsPerP}
            holdBefore
            className="inset-x-0 bottom-5 flex justify-center"
          >
            <div className="flex items-center gap-3 rounded-full border border-white/20 bg-black/30 px-4 py-2 font-mono text-[10.5px] uppercase tracking-[0.28em] text-white/80 backdrop-blur-md">
              <span className="relative h-5 w-[1.5px] overflow-hidden bg-white/25">
                <motion.span
                  className="absolute inset-x-0 top-0 h-2 bg-white"
                  animate={{ y: [-8, 20] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
                />
              </span>
              Scroll
            </div>
          </Panel>

          {/* 1 · mission (left) */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[1]}
            unitsPerP={geo.unitsPerP}
            className="bottom-[8dvh] left-5 md:bottom-auto md:left-[7vw] md:top-1/2 md:-translate-y-1/2"
          >
            <div className={textCard}>
              <Eyebrow>01 · Our mission</Eyebrow>
              <h2 className="m-0 mb-5 font-display text-[clamp(32px,4.2vw,56px)] font-semibold leading-[1.02] tracking-[-0.02em]">
                Our Mission
              </h2>
              <p className="m-0 mb-4 text-[14.5px] leading-[1.75] text-white/75">
                We translate the world&apos;s heritage buildings into refined,
                print-ready 3D models — every cornice, arch and column rebuilt
                by hand, so history can sit on your shelf.
              </p>
              <p className="m-0 mb-7 text-[14.5px] leading-[1.75] text-white/75">
                By mapping and measuring each landmark with care, we keep the
                proportions honest and the details crisp enough to print.
              </p>
              <Link
                href="/studio"
                className="inline-flex items-center gap-2 rounded-md border border-white/30 bg-white/95 px-4 py-2 text-[12px] font-semibold text-[#150c34] no-underline transition-transform hover:scale-[1.03]"
              >
                Learn more
              </Link>
            </div>
          </Panel>

          {/* 2 · advantages (right) */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[2]}
            unitsPerP={geo.unitsPerP}
            className="bottom-[8dvh] left-5 md:bottom-auto md:left-auto md:right-[7vw] md:top-1/2 md:-translate-y-1/2"
          >
            <div className={textCard}>
              <Eyebrow>02 · Our advantages</Eyebrow>
              <h2 className="m-0 mb-5 font-display text-[clamp(32px,4.2vw,56px)] font-semibold leading-[1.02] tracking-[-0.02em]">
                Our Advantages
              </h2>
              <h3 className="m-0 mb-1.5 text-[14px] font-bold text-white">
                Faithful to the original.
              </h3>
              <p className="m-0 mb-5 text-[14px] leading-[1.7] text-white/70">
                Archival drawings, site surveys and photogrammetry set the
                proportions before a single polygon is drawn.
              </p>
              <h3 className="m-0 mb-1.5 text-[14px] font-bold text-white">
                Boldly print-ready.
              </h3>
              <p className="m-0 text-[14px] leading-[1.7] text-white/70">
                Clean, layered parts — walls, roofs, domes, details — tested on
                Bambu Lab printers and split for multi-colour builds.
              </p>
            </div>
          </Panel>

          {/* 3 · studio (left) */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[3]}
            unitsPerP={geo.unitsPerP}
            className="bottom-[8dvh] left-5 md:bottom-auto md:left-[7vw] md:top-1/2 md:-translate-y-1/2"
          >
            <div className={textCard}>
              <Eyebrow>03 · The Studio</Eyebrow>
              <h2 className="m-0 mb-5 font-display text-[clamp(30px,3.8vw,52px)] font-semibold leading-[1.04] tracking-[-0.02em]">
                A Model Built For You
              </h2>
              <p className="m-0 mb-4 text-[14.5px] leading-[1.75] text-white/75">
                Pick a landmark, reshape its layers, choose your filament
                colours, set your printer and download — all in the browser.
              </p>
              <ul className="m-0 mb-0 list-none space-y-2.5 p-0 text-[14px] text-white/80">
                {[
                  "Live 3D preview with transform gizmo",
                  "Per-layer height & visibility controls",
                  "Export multi-colour 3MF or a merged STL",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3">
                    <span
                      className="mt-[9px] h-[5px] w-[5px] shrink-0 rotate-45"
                      style={{ background: "var(--accent)" }}
                    />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </Panel>

          {/* 4 · finale */}
          <Panel
            progress={scrollYProgress}
            at={geo.at[4]}
            unitsPerP={geo.unitsPerP}
            holdAfter
            className="inset-x-0 bottom-[7dvh] flex justify-center px-5"
          >
            <div className="flex w-[min(560px,100%)] flex-col items-center rounded-3xl border border-white/15 bg-[#0d0a22]/60 px-8 py-8 text-center text-white backdrop-blur-xl">
              <h2 className="m-0 mb-3 font-display text-[clamp(28px,3.6vw,44px)] font-semibold tracking-[-0.02em]">
                Step inside the Studio.
              </h2>
              <p className="m-0 mb-6 max-w-[420px] text-[14.5px] leading-[1.7] text-white/75">
                Choose a landmark and make it yours.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link
                  href="/studio"
                  className="rounded-full px-6 py-3 text-[13.5px] font-bold text-[#150c34] no-underline transition-transform hover:scale-[1.04]"
                  style={{ background: "linear-gradient(100deg,#ffd29a,#ff9a5c 55%,#f0709a)" }}
                >
                  Open the Studio
                </Link>
                <Link
                  href="/login"
                  className="rounded-full border border-white/30 px-6 py-3 text-[13.5px] font-medium text-white no-underline transition-colors hover:bg-white/10"
                >
                  Sign in
                </Link>
              </div>
            </div>
          </Panel>
        </div>

        {/* progress hairline */}
        <div className="pointer-events-none absolute right-0 top-0 hidden h-full w-[3px] bg-white/[0.06] md:block">
          <motion.div
            className="h-full w-full origin-top"
            style={{
              scaleY: barScale,
              background: "linear-gradient(180deg,#ffd29a,#ff9a5c,#e0589b)",
            }}
          />
        </div>
      </div>
    </section>
  );
}