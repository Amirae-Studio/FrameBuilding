/**
 * Heritage scroll-world artwork — pure SVG, no hooks, so it can be rendered
 * on the server and previewed as a still. World space is 1600 × 5200.
 *
 *   0 – 1010   S0  dusk canal between heritage terraces (hero)
 *   1010–2050  S1  cut-away of a heritage building (mission)
 *   2050–3050  S2  workshop: wheel + glass-domed models (advantages)
 *   3050–4050  S3  forge: a landmark being printed (studio)
 *   4050–5200  S4  cave mouth opening onto the sunset (call to action)
 */
import type { ReactNode } from "react";

export const WORLD_W = 1600;
export const WORLD_H = 5200;

/** y-centre of each scene (used to time the text panels). */
export const SCENE_CENTERS = [520, 1530, 2550, 3550, 4620] as const;

/* ------------------------------------------------------------------ helpers */

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
type P = [number, number];
const pts = (ps: P[]) => ps.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");

/** Bilinear point on a quad given as [TL, TR, BR, BL]. */
function bi(q: [P, P, P, P], u: number, v: number): P {
  const top: P = [lerp(q[0][0], q[1][0], u), lerp(q[0][1], q[1][1], u)];
  const bot: P = [lerp(q[3][0], q[2][0], u), lerp(q[3][1], q[2][1], u)];
  return [lerp(top[0], bot[0], v), lerp(top[1], bot[1], v)];
}

/* ------------------------------------------------------------------- defs */

export function WorldDefs() {
  return (
    <defs>
      <linearGradient id="g-sky" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="640">
        <stop offset="0" stopColor="#6a4c97" />
        <stop offset="0.38" stopColor="#b782b6" />
        <stop offset="0.66" stopColor="#f09c90" />
        <stop offset="0.9" stopColor="#ffc47c" />
        <stop offset="1" stopColor="#ffdca0" />
      </linearGradient>
      <radialGradient id="g-sun" gradientUnits="userSpaceOnUse" cx="800" cy="560" r="480">
        <stop offset="0" stopColor="#fff0c0" stopOpacity="0.95" />
        <stop offset="0.35" stopColor="#ffc47c" stopOpacity="0.5" />
        <stop offset="1" stopColor="#ffc47c" stopOpacity="0" />
      </radialGradient>
      <linearGradient id="g-water" gradientUnits="userSpaceOnUse" x1="0" y1="570" x2="0" y2="1010">
        <stop offset="0" stopColor="#e4f0ff" />
        <stop offset="0.45" stopColor="#86b6f4" />
        <stop offset="1" stopColor="#9a84ee" />
      </linearGradient>
      <linearGradient id="g-ground" gradientUnits="userSpaceOnUse" x1="0" y1="560" x2="0" y2="1010">
        <stop offset="0" stopColor="#6a4a96" />
        <stop offset="1" stopColor="#2c1a58" />
      </linearGradient>
      <linearGradient id="g-glow" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffbf72" />
        <stop offset="0.55" stopColor="#f2757f" />
        <stop offset="1" stopColor="#c44a9a" />
      </linearGradient>
      <linearGradient id="g-violet-room" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#7d62e8" />
        <stop offset="1" stopColor="#3d2a8c" />
      </linearGradient>
      <linearGradient id="g-fall" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stopColor="#9db4ff" stopOpacity="0" />
        <stop offset="0.5" stopColor="#d6e0ff" stopOpacity="0.85" />
        <stop offset="1" stopColor="#9db4ff" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="g-world" gradientUnits="userSpaceOnUse" x1="0" y1="980" x2="0" y2="4100">
        <stop offset="0" stopColor="#21144f" />
        <stop offset="0.5" stopColor="#170e3d" />
        <stop offset="1" stopColor="#120a2f" />
      </linearGradient>
      <linearGradient id="g-lamp" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffe9a0" stopOpacity="0.95" />
        <stop offset="1" stopColor="#ffe9a0" stopOpacity="0" />
      </linearGradient>
      <linearGradient id="g-cave-sky" gradientUnits="userSpaceOnUse" x1="0" y1="4300" x2="0" y2="5050">
        <stop offset="0" stopColor="#4a3482" />
        <stop offset="0.45" stopColor="#d4609a" />
        <stop offset="0.8" stopColor="#ff9f6b" />
        <stop offset="1" stopColor="#ffd08a" />
      </linearGradient>
      <linearGradient id="g-cave-sea" gradientUnits="userSpaceOnUse" x1="0" y1="5000" x2="0" y2="5200">
        <stop offset="0" stopColor="#ffb98a" />
        <stop offset="0.5" stopColor="#a56bc4" />
        <stop offset="1" stopColor="#3d2a7c" />
      </linearGradient>
      <radialGradient id="g-orb">
        <stop offset="0" stopColor="#fff2c4" />
        <stop offset="0.45" stopColor="#ffbd6a" />
        <stop offset="1" stopColor="#ff9a5c" stopOpacity="0" />
      </radialGradient>
      <radialGradient id="g-cave-sun" gradientUnits="userSpaceOnUse" cx="470" cy="4985" r="460">
        <stop offset="0" stopColor="#fff4cf" stopOpacity="1" />
        <stop offset="0.3" stopColor="#ffc47c" stopOpacity="0.6" />
        <stop offset="1" stopColor="#ffc47c" stopOpacity="0" />
      </radialGradient>
      <linearGradient id="g-mist" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#ffd9c8" stopOpacity="0" />
        <stop offset="1" stopColor="#ffd9c8" stopOpacity="0.55" />
      </linearGradient>
      <filter id="f-blur" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="14" />
      </filter>
      <filter id="f-blur-s" x="-30%" y="-30%" width="160%" height="160%">
        <feGaussianBlur stdDeviation="5" />
      </filter>
    </defs>
  );
}

/* --------------------------------------------------------- SKY (slow layer) */

function Cloud({ x, y, s = 1, o = 0.5 }: { x: number; y: number; s?: number; o?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o} fill="#ffe6ee">
      <ellipse cx="0" cy="0" rx="120" ry="22" />
      <ellipse cx="-60" cy="-14" rx="64" ry="20" />
      <ellipse cx="40" cy="-20" rx="80" ry="24" />
    </g>
  );
}

function Mountain({
  peak,
  base,
  light,
  dark,
  mid,
}: {
  peak: P;
  base: [number, number];
  light: string;
  dark: string;
  mid: P;
}) {
  const [bl, br] = base;
  const by = 640;
  return (
    <g>
      <polygon points={pts([[bl, by], peak, mid, [lerp(bl, peak[0], 0.55), by]])} fill={light} />
      <polygon points={pts([peak, [br, by], [lerp(br, peak[0], 0.5), by], mid])} fill={dark} />
      <polygon
        points={pts([peak, [lerp(peak[0], bl, 0.16), lerp(peak[1], by, 0.2)], [lerp(peak[0], br, 0.1), lerp(peak[1], by, 0.16)]])}
        fill="#f6e4f4"
        opacity="0.7"
      />
    </g>
  );
}

/** Sky, sun, clouds and mountains. Rendered on the slow parallax layer. */
export function SkyLayer() {
  return (
    <g>
      {/* extended upward so the slow layer never runs out of sky */}
      <rect x="-200" y="-2400" width="2000" height="2400" fill="#6a4c97" />
      <rect x="-200" y="0" width="2000" height="660" fill="url(#g-sky)" />
      <rect x="-200" y="0" width="2000" height="660" fill="url(#g-sun)" />

      <Cloud x={260} y={150} s={1.2} o={0.35} />
      <Cloud x={1330} y={110} s={1.4} o={0.3} />
      <Cloud x={980} y={260} s={0.9} o={0.4} />
      <Cloud x={520} y={330} s={1} o={0.45} />

      {/* back range */}
      <Mountain peak={[430, 360]} base={[100, 900]} mid={[470, 520]} light="#a98ad2" dark="#8467b4" />
      <Mountain peak={[1180, 330]} base={[860, 1500]} mid={[1210, 520]} light="#a98ad2" dark="#8467b4" />
      {/* hero peak */}
      <Mountain peak={[800, 150]} base={[300, 1300]} mid={[820, 420]} light="#c3a6e6" dark="#7a58b0" />
      <rect x="-200" y="470" width="2000" height="190" fill="url(#g-mist)" />
      <Cloud x={700} y={470} s={1.6} o={0.5} />
      <Cloud x={1000} y={520} s={1.3} o={0.45} />
    </g>
  );
}

/* ----------------------------------------------- S0: perspective terraces */

const VP: P = [800, 560];
const TOP0 = -160; // roofline y at x = 0
const BOT0 = 900; // street line y at x = 0

function yAt(x: number, y0: number, scale = 1) {
  const f = (VP[0] - x) / VP[0]; // 1 at x=0, 0 at centre
  const base = lerp(VP[1], y0, f);
  return lerp(VP[1], base, scale);
}

const FACADE = ["#8e4560", "#a95468", "#5f3a7c", "#b4684f", "#744a8a", "#9b4f5f"];

function Terrace({ side, seed }: { side: "L" | "R"; seed: number }) {
  const r = rng(seed);
  // segment edges measured from the outer border towards the centre
  const edges = [0, 150, 300, 430, 540, 625];
  const scales = [1.1, 0.78, 1.0, 0.7, 0.88];
  const out: ReactNode[] = [];

  // draw far -> near
  for (let i = edges.length - 2; i >= 0; i--) {
    const a = edges[i];
    const b = edges[i + 1];
    const xa = side === "L" ? a : WORLD_W - a;
    const xb = side === "L" ? b : WORLD_W - b;
    const sc = scales[i];
    const topA = yAt(side === "L" ? xa : WORLD_W - xa, TOP0, sc);
    const topB = yAt(side === "L" ? xb : WORLD_W - xb, TOP0, sc);
    const botA = yAt(side === "L" ? xa : WORLD_W - xa, BOT0);
    const botB = yAt(side === "L" ? xb : WORLD_W - xb, BOT0);
    const q: [P, P, P, P] = [
      [xa, topA],
      [xb, topB],
      [xb, botB],
      [xa, botA],
    ];
    const col = FACADE[(i * 2 + (side === "L" ? 0 : 3)) % FACADE.length];
    out.push(
      <g key={`b${i}`}>
        <polygon points={pts(q)} fill={col} />
        {/* sunset light grading toward the centre */}
        <polygon points={pts(q)} fill="#ff9a5c" opacity={0.12 + 0.05 * (edges.length - i)} />
        {/* cornice */}
        <polygon
          points={pts([
            [xa, topA - 22 * (1 - a / 700)],
            [xb, topB - 22 * (1 - b / 700)],
            [xb, topB + 6],
            [xa, topA + 6],
          ])}
          fill="#3c2467"
        />
        {/* string course */}
        {[0.36, 0.7].map((v) => {
          const p1 = bi(q, 0, v);
          const p2 = bi(q, 1, v);
          return <line key={v} x1={p1[0]} y1={p1[1]} x2={p2[0]} y2={p2[1]} stroke="#2a1750" strokeWidth={3 * (1 - a / 800)} opacity="0.7" />;
        })}
        {/* arched windows */}
        {Array.from({ length: 3 }).map((_, c) =>
          Array.from({ length: 6 }).map((__, rw) => {
            const u0 = 0.12 + c * 0.29;
            const u1 = u0 + 0.19;
            const v0 = 0.07 + rw * 0.145;
            const v1 = v0 + 0.1;
            const tl = bi(q, u0, v0);
            const tr = bi(q, u1, v0);
            const br = bi(q, u1, v1);
            const bl = bi(q, u0, v1);
            const h = Math.abs(bl[1] - tl[1]);
            const lit = r() > 0.42;
            const arch = `M${bl[0].toFixed(1)},${bl[1].toFixed(1)} L${tl[0].toFixed(1)},${(tl[1] + h * 0.18).toFixed(1)} Q${((tl[0] + tr[0]) / 2).toFixed(1)},${(tl[1] - h * 0.2).toFixed(1)} ${tr[0].toFixed(1)},${(tr[1] + h * 0.18).toFixed(1)} L${br[0].toFixed(1)},${br[1].toFixed(1)} Z`;
            return <path key={`${c}-${rw}`} d={arch} fill={lit ? "#ffd58a" : "#2b1957"} opacity={lit ? 0.92 : 0.8} />;
          })
        )}
        {/* far end cap */}
        <polygon
          points={pts([
            [xb, topB],
            [xb + (side === "L" ? 6 : -6), topB + 4],
            [xb + (side === "L" ? 6 : -6), botB],
            [xb, botB],
          ])}
          fill="#2a1750"
          opacity="0.7"
        />
      </g>
    );
  }

  // lamps along the street line
  const lamps = [90, 250, 380, 490].map((a, i) => {
    const x = side === "L" ? a + 30 : WORLD_W - a - 30;
    const yb = yAt(x, BOT0 + 20);
    const k = 1 - a / 800;
    const h = 150 * k + 30;
    return (
      <g key={`l${i}`}>
        <polygon
          points={pts([
            [x, yb - h],
            [x - 34 * k - 6, yb - 6],
            [x + 34 * k + 6, yb - 6],
          ])}
          fill="url(#g-lamp)"
        />
        <line x1={x} y1={yb} x2={x} y2={yb - h} stroke="#2a1750" strokeWidth={3 * k + 1} />
        <circle cx={x} cy={yb - h} r={4 * k + 2} fill="#fff1b8" />
      </g>
    );
  });

  return (
    <g>
      {out}
      {lamps}
    </g>
  );
}

function Rock({ x, y, w, h, c }: { x: number; y: number; w: number; h: number; c: string }) {
  return (
    <g>
      <polygon
        points={pts([
          [x, y],
          [x + w * 0.2, y - h * 0.85],
          [x + w * 0.55, y - h],
          [x + w * 0.9, y - h * 0.55],
          [x + w, y],
        ])}
        fill={c}
      />
      <polygon
        points={pts([
          [x + w * 0.55, y - h],
          [x + w * 0.9, y - h * 0.55],
          [x + w, y],
          [x + w * 0.5, y],
        ])}
        fill="#000"
        opacity="0.18"
      />
    </g>
  );
}

export function HeroScene() {
  return (
    <g>
      {/* street + water */}
      <polygon points={pts([[0, BOT0], VP, [1600, BOT0], [1600, 1020], [0, 1020]])} fill="url(#g-ground)" />
      <polygon points={pts([[772, 574], [828, 574], [1340, 1020], [260, 1020]])} fill="url(#g-water)" />
      {/* foam streaks */}
      {[0.1, 0.22, 0.36, 0.5, 0.66, 0.82].map((t, i) => {
        const y = lerp(578, 1010, t);
        const half = lerp(26, 540, t);
        return (
          <path
            key={i}
            d={`M${800 - half * 0.7},${y} q${half * 0.35},${-6 - t * 10} ${half * 0.7},0 t${half * 0.7},0`}
            stroke="#ffffff"
            strokeWidth={1.5 + t * 2.5}
            fill="none"
            opacity={0.55}
          />
        );
      })}
      {/* waterfall at the vanishing point */}
      <rect x="788" y="360" width="24" height="220" fill="#eaf3ff" opacity="0.92" />
      <rect x="796" y="360" width="8" height="220" fill="#ffffff" opacity="0.8" />
      <ellipse cx="800" cy="580" rx="70" ry="12" fill="#ffffff" opacity="0.7" filter="url(#f-blur-s)" />

      <Terrace side="L" seed={11} />
      <Terrace side="R" seed={29} />

      {/* foreground rocks, tinted by the dusk */}
      <Rock x={-40} y={1022} w={300} h={110} c="#8d4f93" />
      <Rock x={190} y={1022} w={190} h={70} c="#a763a4" />
      <Rock x={1290} y={1022} w={330} h={120} c="#8d4f93" />
      <Rock x={1130} y={1022} w={200} h={64} c="#a763a4" />
      <Rock x={620} y={1022} w={120} h={34} c="#b774b0" />
      <Rock x={930} y={1022} w={110} h={30} c="#b774b0" />
      {/* jagged ledge the canal spills over — leaves a gap for the falls */}
      <polygon
        points="-50,1016 40,1034 130,1018 240,1040 318,1020 318,1060 -50,1060"
        fill="#1b1046"
      />
      <polygon
        points="568,1020 640,1038 760,1018 880,1042 1010,1020 1130,1040 1250,1018 1380,1038 1650,1016 1650,1060 568,1060"
        fill="#1b1046"
      />
      <ellipse cx="443" cy="1016" rx="130" ry="10" fill="#eaf3ff" opacity="0.8" />
    </g>
  );
}

/* ------------------------------------------------------ waterfall (S0 → S3) */

export function Waterfall() {
  const r = rng(5);
  const bars = Array.from({ length: 16 }).map((_, i) => {
    const x = 330 + i * 14 + r() * 6;
    const w = 6 + r() * 12;
    const o = 0.25 + r() * 0.55;
    return (
      <rect
        key={i}
        className="hb-shimmer"
        style={{ animationDelay: `${(i % 7) * 0.35}s` }}
        x={x}
        y={1016}
        width={w}
        height={3190}
        fill="url(#g-fall)"
        opacity={o}
      />
    );
  });
  return (
    <g>
      <rect x="318" y="1016" width="250" height="3190" fill="#8da0ff" opacity="0.1" />
      {bars}
      <ellipse cx="445" cy="4200" rx="190" ry="26" fill="#d6e0ff" opacity="0.28" filter="url(#f-blur)" />
    </g>
  );
}

/* ---------------------------------------------------------------- figures */

function Figure({ x, y, s = 1, c = "#150c34" }: { x: number; y: number; s?: number; c?: string }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill={c}>
      <circle cx="0" cy="-46" r="7" />
      <path d="M-9,0 L-7,-36 Q0,-42 7,-36 L9,0 Z" />
    </g>
  );
}

function Orb({ x, y, r = 14, o = 1 }: { x: number; y: number; r?: number; o?: number }) {
  return <circle cx={x} cy={y} r={r} fill="url(#g-orb)" opacity={o} />;
}

/* ------------------------------------------------- S1: cut-away building */

function Arch({ x, y, w, h, fill, o = 1 }: { x: number; y: number; w: number; h: number; fill: string; o?: number }) {
  return (
    <path
      d={`M${x},${y + h} V${y + w / 2} A${w / 2},${w / 2} 0 0 1 ${x + w},${y + w / 2} V${y + h} Z`}
      fill={fill}
      opacity={o}
    />
  );
}

function CutawayBuilding() {
  const cols = [840, 968, 1096, 1224, 1352, 1470];
  return (
    <g>
      {/* soft light spill */}
      <ellipse cx="1150" cy="1650" rx="520" ry="360" fill="#e0589b" opacity="0.14" filter="url(#f-blur)" />
      {/* pediment + body */}
      <polygon points="780,1190 1150,1040 1520,1190" fill="#2d1c6b" />
      <polygon points="830,1180 1150,1062 1470,1180" fill="#3a2585" />
      <circle cx="1150" cy="1128" r="22" fill="#ffbf72" opacity="0.9" />
      <rect x="800" y="1190" width="700" height="780" fill="#1d1250" />
      <rect x="800" y="1190" width="700" height="780" fill="none" stroke="#6c52c8" strokeOpacity="0.35" />
      {/* frieze arches */}
      {Array.from({ length: 6 }).map((_, i) => (
        <Arch key={i} x={826 + i * 112} y={1212} w={60} h={74} fill={i % 2 ? "#ffb867" : "#c9a2ff"} o={0.95} />
      ))}
      {/* floors */}
      <rect x="816" y="1300" width="668" height="96" rx="6" fill="url(#g-violet-room)" />
      <rect x="816" y="1424" width="668" height="170" rx="6" fill="url(#g-glow)" />
      <rect x="816" y="1622" width="668" height="170" rx="6" fill="url(#g-violet-room)" opacity="0.8" />
      <rect x="816" y="1820" width="668" height="130" rx="6" fill="#2a1a6a" />
      {/* tall arched windows on the third floor */}
      {[0, 1, 2, 3, 4].map((i) => (
        <Arch key={i} x={850 + i * 126} y={1636} w={70} h={150} fill="#ffb867" o={i === 2 ? 0.95 : 0.22} />
      ))}
      {/* ground-floor doorway with a glowing model on a plinth */}
      <Arch x={1090} y={1832} w={120} h={118} fill="url(#g-glow)" o={0.95} />
      <rect x="1126" y="1900" width="48" height="50" fill="#1d1250" />
      <MiniLandmark x={1150} y={1900} s={0.4} />
      {[1396, 1594, 1792].map((y) => (
        <rect key={y} x="800" y={y} width="700" height="28" fill="#4a32a0" />
      ))}
      {/* columns */}
      {cols.map((x) => (
        <g key={x}>
          <rect x={x - 10} y="1190" width="20" height="780" fill="#3d2889" />
          <rect x={x - 14} y="1190" width="28" height="12" fill="#5a40b8" />
          <rect x={x - 14} y="1958" width="28" height="12" fill="#5a40b8" />
        </g>
      ))}
      {/* stairs */}
      <polyline points="864,1594 904,1622 944,1594 984,1622" stroke="#ffb867" strokeWidth="3" fill="none" opacity="0.7" />
      <polyline points="864,1792 904,1820 944,1792 984,1820" stroke="#c9b4ff" strokeWidth="3" fill="none" opacity="0.5" />
      {/* inhabitants */}
      <Figure x={1030} y={1594} s={1.5} />
      <Figure x={1090} y={1594} s={1.4} />
      <Figure x={1330} y={1594} s={1.5} />
      <Figure x={1180} y={1792} s={1.3} c="#0f0828" />
      <Figure x={1250} y={1792} s={1.3} c="#0f0828" />
      <Figure x={1050} y={1394} s={1.1} c="#120a30" />
      <Orb x={1220} y={1500} r={30} />
      <Orb x={1290} y={1470} r={20} o={0.85} />
      <Orb x={1400} y={1520} r={24} o={0.9} />
      <Orb x={1300} y={1700} r={22} o={0.7} />
      <Orb x={1010} y={1700} r={18} o={0.7} />
      {/* sliding glass balcony on the far left */}
      <rect x="700" y="1594" width="120" height="8" fill="#ffb867" opacity="0.8" />
      <Figure x={745} y={1594} s={1.4} />
    </g>
  );
}

/* ---------------------------------------------------- S2: workshop wheel */

function Gear({ cx, cy, r }: { cx: number; cy: number; r: number }) {
  const teeth = 24;
  return (
    <g transform={`translate(${cx} ${cy})`}>
      <g className="hb-spin">
        {Array.from({ length: teeth }).map((_, i) => (
          <rect
            key={i}
            x={-9}
            y={-r - 16}
            width="18"
            height="26"
            rx="3"
            fill="#7a5be0"
            transform={`rotate(${(360 / teeth) * i})`}
          />
        ))}
        <circle r={r} fill="none" stroke="#6347d0" strokeWidth="26" />
        <circle r={r - 34} fill="#1d1250" stroke="#e0589b" strokeWidth="6" />
        {Array.from({ length: 8 }).map((_, i) => (
          <rect key={i} x="-9" y={-(r - 34)} width="18" height={r - 34} fill="#3a2585" transform={`rotate(${45 * i})`} />
        ))}
        <circle r="34" fill="#4a32a0" />
        <circle r="14" fill="#ffb867" />
      </g>
    </g>
  );
}

function MiniLandmark({ x, y, s = 1, glow = "#ffb867" }: { x: number; y: number; s?: number; glow?: string }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x="-40" y="-52" width="80" height="52" fill={glow} opacity="0.95" />
      <polygon points="-48,-52 0,-82 48,-52" fill="#ffd58a" />
      <rect x="-12" y="-98" width="24" height="18" fill={glow} />
      <path d="M-14,-98 A14,14 0 0 1 14,-98 Z" fill="#ffe3a8" />
      {[-26, -9, 9, 26].map((dx) => (
        <rect key={dx} x={dx - 4} y="-44" width="8" height="30" rx="4" fill="#2a1750" opacity="0.55" />
      ))}
      <rect x="-52" y="-4" width="104" height="8" fill="#d8a96a" />
    </g>
  );
}

function Dome({ x, y, w, h }: { x: number; y: number; w: number; h: number }) {
  return (
    <path
      d={`M${x},${y} A${w / 2},${h} 0 0 1 ${x + w},${y} Z`}
      fill="#a79bff"
      fillOpacity="0.14"
      stroke="#cbbfff"
      strokeOpacity="0.7"
      strokeWidth="3"
    />
  );
}

function Workshop() {
  return (
    <g>
      {/* arches & pipes in the background */}
      <path d="M-20,2440 Q250,2230 520,2440" stroke="#2f1d70" strokeWidth="22" fill="none" />
      <rect x="-20" y="2440" width="1640" height="10" fill="#241557" />
      <rect x="880" y="2150" width="14" height="300" fill="#2a1a63" />
      {/* wheel */}
      <Gear cx={560} cy={2560} r={170} />
      <rect x="330" y="2740" width="460" height="14" fill="#e0589b" opacity="0.85" />
      <rect x="330" y="2754" width="460" height="6" fill="#5a40b8" />
      {Array.from({ length: 12 }).map((_, i) => (
        <rect key={i} x={340 + i * 40} y="2700" width="4" height="40" fill="#e0589b" opacity="0.7" />
      ))}
      <Figure x={400} y={2740} s={1.3} c="#0f0828" />
      {/* display table with glass domes */}
      <rect x="1000" y="2760" width="520" height="14" fill="#4a32a0" />
      <rect x="1000" y="2774" width="520" height="8" fill="#241557" />
      <rect x="1030" y="2782" width="10" height="170" fill="#241557" />
      <rect x="1480" y="2782" width="10" height="170" fill="#241557" />
      <Dome x={1040} y={2760} w={190} h={150} />
      <Dome x={1290} y={2760} w={190} h={150} />
      <MiniLandmark x={1135} y={2756} s={0.95} />
      <MiniLandmark x={1385} y={2756} s={0.8} glow="#f2757f" />
      <Orb x={1135} y={2640} r={44} o={0.5} />
      <Orb x={1385} y={2660} r={40} o={0.4} />
      <Figure x={1270} y={2762} s={1.5} c="#0f0828" />
      {/* hanging lamp */}
      <line x1="1200" y1="2150" x2="1200" y2="2420" stroke="#2f1d70" strokeWidth="4" />
      <circle cx="1200" cy="2430" r="16" fill="#ffd58a" />
      <Orb x={1200} y={2430} r={60} o={0.55} />
    </g>
  );
}

/* ------------------------------------------------------- S3: print forge */

function Forge() {
  return (
    <g>
      {/* tower */}
      <rect x="880" y="3130" width="380" height="800" fill="#1b1148" />
      <rect x="880" y="3130" width="380" height="800" fill="none" stroke="#6c52c8" strokeOpacity="0.3" />
      <polygon points="860,3130 1070,3060 1280,3130" fill="#2a1a63" />
      {[930, 1010, 1090, 1170].map((x) => (
        <g key={x}>
          <rect x={x} y="3200" width="16" height="190" rx="8" fill="#ff9a5c" />
          <rect x={x - 6} y="3200" width="28" height="190" rx="14" fill="#ff9a5c" opacity="0.35" filter="url(#f-blur-s)" />
        </g>
      ))}
      {/* print gantry */}
      <rect x="640" y="3490" width="820" height="20" rx="4" fill="#4a32a0" />
      <rect x="650" y="3440" width="16" height="400" fill="#3a2585" />
      <rect x="1434" y="3440" width="16" height="400" fill="#3a2585" />
      <rect x="1030" y="3510" width="74" height="46" rx="6" fill="#6347d0" />
      <polygon points="1054,3556 1080,3556 1067,3590" fill="#ffb867" />
      <Orb x={1067} y={3596} r={26} />
      {/* build plate with a landmark half-printed */}
      <rect x="900" y="3830" width="330" height="22" rx="4" fill="#4a32a0" />
      <rect x="960" y="3752" width="210" height="78" fill="#ffb867" />
      <rect x="960" y="3752" width="210" height="78" fill="url(#g-glow)" opacity="0.45" />
      {[0, 1, 2, 3, 4].map((i) => (
        <rect key={i} x={978 + i * 40} y="3764" width="14" height="56" rx="7" fill="#2a1750" opacity="0.55" />
      ))}
      {/* ghost of the rest */}
      <polygon points="948,3752 1065,3664 1182,3752" fill="none" stroke="#ffd58a" strokeWidth="3" strokeDasharray="10 8" opacity="0.8" />
      <rect x="1040" y="3620" width="50" height="46" fill="none" stroke="#ffd58a" strokeWidth="3" strokeDasharray="10 8" opacity="0.7" />
      <path d="M1040,3620 A25,25 0 0 1 1090,3620" fill="none" stroke="#ffd58a" strokeWidth="3" strokeDasharray="10 8" opacity="0.7" />
      {/* layer lines */}
      {[3700, 3716, 3732].map((y) => (
        <line key={y} x1="962" y1={y} x2="1168" y2={y} stroke="#ffd58a" strokeWidth="2" opacity="0.35" />
      ))}
      {/* conveyor of gears */}
      <rect x="420" y="3880" width="1100" height="14" fill="#241557" />
      <Gear cx={560} cy={3850} r={60} />
      <Gear cx={700} cy={3868} r={44} />
      {/* side vats */}
      <rect x="1330" y="3640" width="140" height="190" rx="14" fill="#2a1a63" />
      <rect x="1346" y="3700" width="108" height="112" rx="8" fill="url(#g-glow)" opacity="0.8" />
      <Figure x={800} y={3880} s={1.4} c="#0f0828" />
      <Orb x={760} y={3560} r={30} o={0.7} />
      <Orb x={1380} y={3390} r={22} o={0.6} />
    </g>
  );
}

/* --------------------------------------------------- S4: cave to sunset */

function CaveFinale() {
  const r = rng(77);
  const waves = Array.from({ length: 14 }).map((_, i) => {
    const y = 5030 + i * 12;
    const x = 360 + r() * 700;
    const w = 40 + r() * 160;
    return <rect key={i} x={x} y={y} width={w} height="3" rx="1.5" fill="#fff0c8" opacity={0.25 + r() * 0.35} />;
  });
  return (
    <g>
      {/* the sunset beyond */}
      <rect x="0" y="4250" width="1600" height="950" fill="url(#g-cave-sky)" />
      <rect x="0" y="4250" width="1600" height="950" fill="url(#g-cave-sun)" />
      <circle cx="470" cy="4975" r="58" fill="#fff4cf" />
      <Cloud x={560} y={4620} s={1.2} o={0.5} />
      <Cloud x={1040} y={4560} s={1} o={0.4} />
      <rect x="0" y="5010" width="1600" height="190" fill="url(#g-cave-sea)" />
      {waves}
      {/* distant islands */}
      <polygon points="260,5014 330,4970 400,5014" fill="#8f5fb5" />
      <polygon points="1210,5014 1330,4880 1470,5014" fill="#6b43a0" />
      {/* hero mountain */}
      <polygon points="880,5030 1110,4560 1290,4780 1360,5030" fill="#8a4f90" />
      <polygon points="1110,4560 1290,4780 1360,5030 1140,5030 1100,4800" fill="#5a2f78" />
      <polygon points="1110,4560 1040,4700 1090,4690 1130,4760" fill="#f6dff0" opacity="0.8" />
      <polygon points="660,5030 820,4830 940,5030" fill="#c9a2e6" />
      <polygon points="820,4830 940,5030 850,5030" fill="#9468c4" />
      {/* birds */}
      {[[540, 4560], [610, 4600], [700, 4530]].map(([x, y], i) => (
        <path key={i} d={`M${x},${y} q10,-10 20,0 q10,-10 20,0`} stroke="#4a2a70" strokeWidth="3" fill="none" />
      ))}
      {/* cave mouth — dark mass with an arched opening */}
      <path
        fillRule="evenodd"
        fill="#0d0820"
        d={`M-50,4050 H1650 V5200 H-50 Z
            M240,5200 V4700 Q240,4300 800,4300 Q1360,4300 1360,4700 V5200 Z`}
      />
      <path d="M240,5200 V4700 Q240,4300 800,4300 Q1360,4300 1360,4700 V5200" fill="none" stroke="#ff9a5c" strokeOpacity="0.5" strokeWidth="4" />
      {/* rim light & stalactites */}
      <path d="M240,4700 Q240,4300 800,4300" fill="none" stroke="#ffd58a" strokeOpacity="0.35" strokeWidth="14" filter="url(#f-blur-s)" />
      {[330, 470, 640, 980, 1130, 1250].map((x, i) => (
        <polygon key={x} points={`${x},4390 ${x + 26},4390 ${x + 13},${4440 + (i % 3) * 22}`} fill="#0d0820" />
      ))}
      {/* ledge in front */}
      <polygon points="0,5200 0,5090 180,5050 380,5090 520,5200" fill="#0d0820" />
      <polygon points="1600,5200 1600,5100 1420,5060 1240,5110 1100,5200" fill="#0d0820" />
    </g>
  );
}

/* ---------------------------------------------------------- embers & world */

function Embers() {
  const r = rng(3);
  return (
    <g>
      {Array.from({ length: 22 }).map((_, i) => {
        const y = 3300 + r() * 1700;
        const x = 200 + r() * 1200;
        return (
          <circle
            key={i}
            className="hb-ember"
            style={{ animationDelay: `${(r() * 6).toFixed(2)}s`, animationDuration: `${(5 + r() * 4).toFixed(1)}s` }}
            cx={x}
            cy={y}
            r={2 + r() * 3}
            fill="#ffb36b"
          />
        );
      })}
    </g>
  );
}

/** Everything except the sky: the main (1×) parallax layer. */
export function WorldLayer() {
  return (
    <g>
      {/* underground / interior backdrop */}
      <rect x="-100" y="1000" width="1800" height="3260" fill="url(#g-world)" />
      {/* faint structural ribs */}
      {[60, 1540].map((x) => (
        <rect key={x} x={x - 20} y="1000" width="40" height="3200" fill="#0f0828" opacity="0.55" />
      ))}
      <HeroScene />
      <Waterfall />
      <CutawayBuilding />
      <Workshop />
      <Forge />
      <CaveFinale />
      <Embers />
    </g>
  );
}
